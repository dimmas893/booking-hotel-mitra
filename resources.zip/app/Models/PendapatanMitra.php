<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PendapatanMitra extends Model
{
    use HasFactory;
    protected $table = 'pendapatanmitra';
    protected $guarded = [];
}
