@extends('layouts.admin.template')
@section('content')
    <div class="main-content">

        <div class="">
            <div class="modal fade" id="add_TU_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
                        </div>
                        <form action="#" method="POST" id="add_TU_form" enctype="multipart/form-data">
                            @csrf
                            <input type="hidden" name="idfasilmitra" value="{{ $fasilitaskolamrenangid }}">
                            <input type="hidden" name="idmitra" value="{{ $fasilitasmitra->idmitra }}">
                            <div class="modal-body">
                                <div class="isMember my-2">
                                    <label for="name">Unit</label>
                                    <select id="package" name="idunit" class="form-control">
                                        <option value="null">--- Pilih Unit ---</option>
                                        @foreach ($unit as $item)
                                            <option value="{{ $item->id }}">{{ $item->namaunit }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="my-2 mt-3">
                                    <div id="sma">
                                        <label for="name">Harga Sewa</label>
                                        <select class="form-control">
                                            <option disabled selected>Mohon Untuk Memilih Unit Terlebih Dahulu</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" id="add_TU_btn" class="btn btn-primary">Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="editTUModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                data-backdrop="static" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Edit</h5>
                        </div>
                        <form action="#" method="POST" id="edit_TU_form" enctype="multipart/form-data">
                            @csrf
                            <input type="hidden" name="id" id="id">
                            <div class="modal-body">
                                <div class="my-2">
                                    <label for="name">Jenis Fasilitas</label>
                                    {{-- <select name="idjenisfasilitas" id="idjenisfasilitas" class="form-control">
                                        <option value="" selected disabled>---Pilih Jenis Fasilitas---</option>
                                        @foreach ($jenis as $item)
                                            <option value="{{ $item->id }}">{{ $item->namajenisfasilitas }}</option>
                                        @endforeach
                                    </select> --}}
                                </div>
                                <div class="my-2">
                                    <label for="name">Nama Fasilitas</label>
                                    <input type="text" name="namafasilitas" id="namafasilitas" class="form-control"
                                        placeholder="Masukan Nama Fasilitas" required>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" id="edit_TU_btn" class="btn btn-success">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <section class="section">
            <div class="section-header">
                <h1>Halaman Data Harga Fasilitas Kolam Renang</h1>
            </div>
            <div class="section-body">
                <div class="row my-5">
                    <div class="col-lg-12">
                        <div class="card shadow">
                            <div class="card-header bg-primary d-flex justify-content-between align-items-center">
                                <h3 class="text-light">Tabel Harga Fasilitas Kolam Renang</h3>
                                <button class="btn btn-light" data-toggle="modal" data-target="#add_TU_modal"><i
                                        class="bi-plus-circle me-2"></i>Tambah Harga Fasilitas Kolam Renang</button>
                            </div>
                            <div>
                                <div class="card-body" id="TU_all">
                                    <h1 class="text-secondary my-5 text-center">
                                        <div class="load-3">
                                            <div class="line"></div>
                                            <div class="line"></div>
                                            <div class="line"></div>
                                        </div>
                                    </h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@section('js')
    <script>
        $('.isMember').on('change', function(e) {
            const selectedPackage = $('#package').val();
            e.preventDefault();
            $.ajax({
                url: '{{ route('ajaxhargakesepakatan', $fasilitaskolamrenangid) }}',
                method: 'get',
                data: {
                    id: selectedPackage
                },
                success: function(response) {
                    console.log(response)
                    $("#sma").html(response);
                }
            });
        });

        $(function() {
            // add new employee ajax request
            $("#add_TU_form").submit(function(e) {
                e.preventDefault();
                const fd = new FormData(this);
                $("#add_TU_btn").text('Loading...');
                $.ajax({
                    url: '{{ route('fasilitas-kolam-renang-store') }}',
                    method: 'post',
                    data: fd,
                    cache: false,
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(response) {
                        if (response.status == 200) {
                            Swal.fire(
                                'Berhasil!',
                                'Berhasil menambah data!',
                                'success'
                            )
                            TU_all();
                            $("#add_TU_btn").text('Save');
                            $("#add_TU_form")[0].reset();
                            $("#add_TU_modal").modal('hide');
                        }
                        if (response.status == 400) {
                            Swal.fire(
                                'Upsss!',
                                'Harga Tersebut Sudah Ada!',
                                'info'
                            )
                            $("#add_TU_btn").text('Loading...');
                        }
                        if (response.status == 300) {
                            Swal.fire(
                                'Upsss!',
                                'Perjanjian harga dan unit belum tersedia!',
                                'info'
                            )
                            $("#add_TU_btn").text('Loading...');
                        }
                    }
                });
            });
            // edit employee ajax request
            $(document).on('click', '.editIcon', function(e) {
                e.preventDefault();
                let id = $(this).attr('id');
                $.ajax({
                    url: '{{ route('fasilitas-kolam-renang-edit') }}',
                    method: 'get',
                    data: {
                        id: id,
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        $("#idjenisfasilitas").val(response.idjenisfasilitas);
                        $("#namafasilitas").val(response.namafasilitas);
                        $("#id").val(response.id);
                    }
                });
            });
            // update employee ajax request
            $("#edit_TU_form").submit(function(e) {
                e.preventDefault();
                const fd = new FormData(this);
                $("#edit_TU_btn").text('Loading...');
                $.ajax({
                    url: '{{ route('fasilitas-kolam-renang-update') }}',
                    method: 'post',
                    data: fd,
                    cache: false,
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(response) {
                        if (response.status == 200) {
                            Swal.fire(
                                'Berhasil!',
                                'Berhasil mengubah data!',
                                'success'
                            )
                            TU_all();
                        }
                        $("#edit_TU_btn").text('Update');
                        $("#edit_TU_form")[0].reset();
                        $("#editTUModal").modal('hide');
                    }
                });
            });
            // delete employee ajax request
            $(document).on('click', '.deleteIcon', function(e) {
                e.preventDefault();
                let id = $(this).attr('id');
                let csrf = '{{ csrf_token() }}';
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: '{{ route('fasilitas-kolam-renang-delete') }}',
                            method: 'post',
                            data: {
                                id: id,
                                _token: csrf
                            },
                            success: function(response) {
                                console.log(response);
                                Swal.fire(
                                    'Deleted!',
                                    'Your file has been deleted.',
                                    'success'
                                )
                                TU_all();
                            }
                        });
                    }
                })
            });
            // fetch all employees ajax request
            TU_all();

            function TU_all() {
                $.ajax({
                    url: '{{ route('fasilitas-kolam-renang-all', $fasilitasmitra) }}',
                    method: 'get',
                    success: function(response) {
                        $("#TU_all").html(response);
                        $("table").DataTable({
                            destroy: true,
                            responsive: true
                        });
                    }
                });
            }
        });
    </script>
@endsection
